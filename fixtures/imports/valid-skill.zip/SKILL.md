---
name: demo
---
# Demo Skill
This archive fixture is intentionally larger than eight bytes.
